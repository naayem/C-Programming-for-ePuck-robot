#ifndef REBOND_H_
#define REBOND_H_

#include <ch.h>
#include <hal.h>


/**
 * @brief Starts the rebond module
 *
 */
void rebondStart(void);


#endif /* REBOND_H_ */
